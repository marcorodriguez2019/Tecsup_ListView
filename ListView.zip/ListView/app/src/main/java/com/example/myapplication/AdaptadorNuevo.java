package com.example.myapplication;

import android.content.Context;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

public class AdaptadorNuevo extends BaseAdapter {
    Context c;
    List<Producto> datos;
    int layaout;

    public AdaptadorNuevo(Context c, List<Producto> datos, int layaout) {
        this.c = c;
        this.datos = datos;
        this.layaout = layaout;
    }

    @Override
    public int getCount() {
        return datos.size();
    }

    @Override
    public Object getItem(int i) {
        return datos.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater  =  LayoutInflater.from(c);
        View v = inflater.inflate(layaout,null);
        TextView nombre = v.findViewById(R.id.nombre);
        nombre.setText(datos.get(i).getNombre());
        TextView precio = v.findViewById(R.id.precio);
        precio.setText(datos.get(i).getPrecio().toString());
        ImageView imageView = (ImageView) v.findViewById(R.id.imagen);
        Glide.with(c).load(datos.get(i).imagen).into(imageView);
        return v;
    }
}
