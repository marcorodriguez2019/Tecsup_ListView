package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView lista_one;
    List<Producto> datos;
    EditText nombre;
    EditText precio;
    EditText edit_imagen;
    Button btn_agregar;
    AdaptadorNuevo adapter;
    int int_eliminar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lista_one = findViewById(R.id.list_one);
        nombre = findViewById(R.id.edit_nombre);
        precio = findViewById(R.id.edit_precio);
        edit_imagen = findViewById(R.id.edit_imagen);
        btn_agregar = findViewById(R.id.btn_agregar);
        btn_agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datos.add(new Producto(
                        nombre.getText().toString(),
                        Double.parseDouble(precio.getText().toString()),
                        edit_imagen.getText().toString()));
                adapter.notifyDataSetChanged();
            }
        });

        datos = new ArrayList<>();

        //ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,datos);
        adapter = new AdaptadorNuevo(this, datos, R.layout.item_producto);
        lista_one.setAdapter(adapter);
        lista_one.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(MainActivity.this, datos.get(i).toString(), Toast.LENGTH_SHORT).show();
                MostrarMenu(view,i);
            }
        });
    }

    void Eliminar(int i) {
        datos.remove(i);
        adapter.notifyDataSetChanged();
    }

    void MostrarMenu(View v,int i) {
        int_eliminar = i;
        PopupMenu popup = new PopupMenu(this, v);
        popup.inflate(R.menu.menu_marco);
        popup.show();
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.btn_menu_eliminar:
                        Eliminar(int_eliminar);
                        return true;
                    case R.id.btn_menu_editar:
                        return true;
                    default:
                        return false;

                }
            }
        });
    }

    ;
}
